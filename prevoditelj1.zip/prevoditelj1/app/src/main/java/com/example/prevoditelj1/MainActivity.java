package com.example.prevoditelj1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button langEnglish, langSpanish, langFrench, langCroatian;
    private Button topicFruits, topicVegetables, topicTransport;
    private Button backToLanguageSelection;
    private TextView langText, topicText, translatedText;
    private String selectedLanguage = "hr"; // Default (Hrvatski)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        langText = findViewById(R.id.langText);
        langEnglish = findViewById(R.id.langEnglish);
        langSpanish = findViewById(R.id.langSpanish);
        langFrench = findViewById(R.id.langFrench);
        langCroatian = findViewById(R.id.langCroatian);

        topicText = findViewById(R.id.topicText);
        topicFruits = findViewById(R.id.topicFruits);
        topicVegetables = findViewById(R.id.topicVegetables);
        topicTransport = findViewById(R.id.topicTransport);
        backToLanguageSelection = findViewById(R.id.backToLanguageSelection);

        translatedText = findViewById(R.id.translatedText);

        // Language selection listeners
        langEnglish.setOnClickListener(view -> setLanguage("en"));
        langSpanish.setOnClickListener(view -> setLanguage("es"));
        langFrench.setOnClickListener(view -> setLanguage("fr"));
        langCroatian.setOnClickListener(view -> setLanguage("hr"));

        // Topic selection listeners
        topicFruits.setOnClickListener(view -> translate("fruit"));
        topicVegetables.setOnClickListener(view -> translate("vegetable"));
        topicTransport.setOnClickListener(view -> translate("transport"));

        // Back button listener
        backToLanguageSelection.setOnClickListener(view -> showLanguageSelection());
    }

    private void setLanguage(String lang) {
        selectedLanguage = lang;

        // Hide language buttons
        langText.setVisibility(View.GONE);
        langEnglish.setVisibility(View.GONE);
        langSpanish.setVisibility(View.GONE);
        langFrench.setVisibility(View.GONE);
        langCroatian.setVisibility(View.GONE);

        // Show topic buttons
        topicText.setVisibility(View.VISIBLE);
        topicFruits.setVisibility(View.VISIBLE);
        topicVegetables.setVisibility(View.VISIBLE);
        topicTransport.setVisibility(View.VISIBLE);

        // Show back button
        backToLanguageSelection.setVisibility(View.VISIBLE);
    }

    private void showLanguageSelection() {
        // Hide topic buttons and translated text
        topicText.setVisibility(View.GONE);
        topicFruits.setVisibility(View.GONE);
        topicVegetables.setVisibility(View.GONE);
        topicTransport.setVisibility(View.GONE);
        translatedText.setVisibility(View.GONE);

        // Hide back button
        backToLanguageSelection.setVisibility(View.GONE);

        // Show language buttons
        langText.setVisibility(View.VISIBLE);
        langEnglish.setVisibility(View.VISIBLE);
        langSpanish.setVisibility(View.VISIBLE);
        langFrench.setVisibility(View.VISIBLE);
        langCroatian.setVisibility(View.VISIBLE);
    }

    private void translate(String topic) {
        String result = "";

        // Translation based on topic
        switch (topic) {
            case "fruit":
                result = translateFruit();
                break;
            case "vegetable":
                result = translateVegetable();
                break;
            case "transport":
                result = translateTransport();
                break;
        }

        // Display translation
        translatedText.setVisibility(View.VISIBLE);
        translatedText.setText(result);
    }

    private String translateFruit() {
        switch (selectedLanguage) {
            case "en":
                return "Apple, Banana, Orange, Grapes, Pineapple";
            case "es":
                return "Manzana, Plátano, Naranja, Uvas, Piña";
            case "fr":
                return "Pomme, Banane, Orange, Raisins, Ananas";
            case "hr":
                return "Jabuka, Banana, Naranča, Grožđe, Ananas";
            default:
                return "";
        }
    }

    private String translateVegetable() {
        switch (selectedLanguage) {
            case "en":
                return "Carrot, Potato, Broccoli, Lettuce, Cucumber";
            case "es":
                return "Zanahoria, Patata, Brócoli, Lechuga, Pepino";
            case "fr":
                return "Carotte, Pomme de terre, Brocoli, Laitue, Concombre";
            case "hr":
                return "Mrkva, Krumpir, Brokula, Salata, Krastavac";
            default:
                return "";
        }
    }

    private String translateTransport() {
        switch (selectedLanguage) {
            case "en":
                return "Car, Bicycle, Bus, Train, Airplane";
            case "es":
                return "Coche, Bicicleta, Autobús, Tren, Avión";
            case "fr":
                return "Voiture, Vélo, Bus, Train, Avion";
            case "hr":
                return "Automobil, Bicikl, Autobus, Vlak, Zrakoplov";
            default:
                return "";
        }
    }
}
