package com.example.bitcoin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private TextView usdText, eurText, gbpText, cadText, jpyText;
    private Button refreshButton;

    private BitcoinApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usdText = findViewById(R.id.usdText);
        eurText = findViewById(R.id.eurText);
        gbpText = findViewById(R.id.gbpText);
        cadText = findViewById(R.id.cadText);
        jpyText = findViewById(R.id.jpyText);
        refreshButton = findViewById(R.id.refreshButton);

        apiService = ApiClient.getClient().create(BitcoinApiService.class);

        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fetchBitcoinPrices();
            }
        });

        fetchBitcoinPrices(); // automatski prvi poziv
    }

    private void fetchBitcoinPrices() {
        Call<Map<String, Map<String, Double>>> call = apiService.getBitcoinPrice("bitcoin", "usd,eur,gbp,cad,jpy");
        call.enqueue(new Callback<Map<String, Map<String, Double>>>() {
            @Override
            public void onResponse(Call<Map<String, Map<String, Double>>> call, Response<Map<String, Map<String, Double>>> response) {
                if (response.isSuccessful()) {
                    Map<String, Map<String, Double>> prices = response.body();
                    if (prices != null && prices.containsKey("bitcoin")) {
                        Map<String, Double> bitcoin = prices.get("bitcoin");
                        usdText.setText("USD: " + bitcoin.get("usd"));
                        eurText.setText("EUR: " + bitcoin.get("eur"));
                        gbpText.setText("GBP: " + bitcoin.get("gbp"));
                        cadText.setText("CAD: " + bitcoin.get("cad"));
                        jpyText.setText("JPY: " + bitcoin.get("jpy"));
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Greška u odgovoru API-ja", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Map<String, Map<String, Double>>> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Neuspješan dohvat: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
