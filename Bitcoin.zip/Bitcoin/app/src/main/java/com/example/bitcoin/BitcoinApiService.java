package com.example.bitcoin;

import java.util.Map;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface BitcoinApiService {
    @GET("simple/price")
    Call<Map<String, Map<String, Double>>> getBitcoinPrice(
            @Query("ids") String ids,
            @Query("vs_currencies") String currencies
    );
}
