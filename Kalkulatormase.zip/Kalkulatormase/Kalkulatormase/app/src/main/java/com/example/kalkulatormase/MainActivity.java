package com.example.kalkulatormase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private double br1,br2;
    private EditText Visina, Tezina;
    private TextView textViewRezultat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Visina=findViewById(R.id.Visina);
        Tezina=findViewById(R.id.Tezina);
        textViewRezultat=findViewById(R.id.textViewRezultat);
    }
    public void takeNumbersFromEditTextAndPutIntoVariables(){
        br1= Double.parseDouble(Tezina.getText().toString());
        br2= Double.parseDouble(Visina.getText().toString());
    }
    public void Izracunaj (View view){
        takeNumbersFromEditTextAndPutIntoVariables();
        br2=br2/100;
        double rezultat= br1/(br2*br2);
        textViewRezultat.setText(Double.toString(rezultat));
    }



}