package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView questionTextView;
    private RadioGroup answerRadioGroup;
    private Button submitButton;

    private String[] questions = {
            "Koji je nadimak Manchester Uniteda?",
            "Koja je godina osnutka Manchester Uniteda?",
            "Koja je boja glavnog dresa Manchester Uniteda?",
            "Koliko je puta Manchester United osvojio Premier ligu?",
            "Koliko puta je Manchester United osvojio Ligu prvaka?",
            "Tko je rekorder po broju nastupa za Manchester United?",
            "Tko je najbolji strijelac u povijesti Manchester Uniteda?",
            "Koji stadion je domaćin Manchester Unitedu?",
            "Koja je titula najvećeg rivala Manchester Uniteda?",
            "Koje je bio prvo ime kluba prije nego što je postao Manchester United?"
    };

    private String[][] answers = {
            {"Crveni vragovi", "Plavi konjići", "Žuti lavovi"},
            {"1878.", "1902.", "1910."},
            {"Crvena", "Plava", "Žuta"},
            {"13", "20", "25"},
            {"1", "3", "5"},
            {"Ryan Giggs", "Bobby Charlton", "Wayne Rooney"},
            {"Wayne Rooney", "Bobby Charlton", "George Best"},
            {"Old Trafford", "Anfield", "Camp Nou"},
            {"Manchester City", "Liverpool", "Chelsea"},
            {"Newton Heath", "East Manchester", "Red Devils"}
    };

    private int[] correctAnswers = {0, 0, 0, 1, 2, 0, 0, 0, 1, 0}; // Indeksi točnih odgovora za svako pitanje

    private int currentQuestionIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        questionTextView = findViewById(R.id.questionTextView);
        answerRadioGroup = findViewById(R.id.answerRadioGroup);
        submitButton = findViewById(R.id.submitButton);

        showQuestion();

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
            }
        });
    }

    private void showQuestion() {
        questionTextView.setText(questions[currentQuestionIndex]);

        RadioButton answer1RadioButton = findViewById(R.id.answer1RadioButton);
        RadioButton answer2RadioButton = findViewById(R.id.answer2RadioButton);
        RadioButton answer3RadioButton = findViewById(R.id.answer3RadioButton);

        answer1RadioButton.setText(answers[currentQuestionIndex][0]);
        answer2RadioButton.setText(answers[currentQuestionIndex][1]);
        answer3RadioButton.setText(answers[currentQuestionIndex][2]);
    }

    private void checkAnswer() {
        int selectedId = answerRadioGroup.getCheckedRadioButtonId();
        if (selectedId == -1) {
            // Ako nije odabran odgovor
            Toast.makeText(MainActivity.this, "Molimo odaberite odgovor.", Toast.LENGTH_SHORT).show();
        } else {
            // Ako je odabran odgovor, provjeravamo je li točan
            RadioButton selectedRadioButton = findViewById(selectedId);
            String selectedAnswer = selectedRadioButton.getText().toString();
            int correctAnswerIndex = correctAnswers[currentQuestionIndex];
            String correctAnswer = answers[currentQuestionIndex][correctAnswerIndex];
            if (selectedAnswer.equals(correctAnswer)) {
                Toast.makeText(MainActivity.this, "Točan odgovor!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Netočan odgovor. Točan odgovor je: " + correctAnswer, Toast.LENGTH_SHORT).show();
            }
            // Prijeđi na sljedeće pitanje
            currentQuestionIndex++;
            if (currentQuestionIndex < questions.length) {
                showQuestion();
            } else {
                // Ako su sva pitanja odgovorena, možete dodati kod za prikaz rezultata ili dodatne radnje.
                Toast.makeText(MainActivity.this, "Kviz je završen!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

