package com.example.projekt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText editTextProm;
    private TextView TextViewPrikaz;
    private ImageView ImageViewSlika;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextProm=findViewById(R.id.editTextProm);
        TextViewPrikaz=findViewById(R.id.TextViewPrikaz);
        ImageViewSlika=findViewById(R.id.ImageViewSlika);
    }
    public void clickButtonPromjenaTeksta(View view){
        String text="";
        text=editTextProm.getText().toString();
        TextViewPrikaz.setText(text);
    }
    public void clickButtonPromjena(View view){
        ImageViewSlika.setImageResource(R.drawable.manutd);
        Toast.makeText(getApplicationContext(),"Darda",Toast.LENGTH_SHORT).show();
    }
    public void clickButtonPromjenaa (View view){
        ImageViewSlika.setImageResource(R.drawable.darda);
        Toast.makeText(getApplicationContext(),"Darda",Toast.LENGTH_SHORT).show();
    }
}