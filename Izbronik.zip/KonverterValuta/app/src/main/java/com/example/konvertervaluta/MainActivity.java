package com.example.konvertervaluta;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private double br,br2,br3,br4,br5,br6;
    private EditText editTextBroj;
    private ImageView Slika;
    private int broj;
    private TextView Rez;
    private ImageView mImageView;
    Random rand = new Random();

    private double broj1,broj2;
    private EditText editTextBroj1, editTextBroj2;
    private TextView textViewRezultat;

    private EditText inputText;
    private Button translateButton;
    private TextView outputText;

    private TextView textViewRezultat1,textViewRezultat2,textViewRezultat3,textViewRezultat4,textViewRezultat5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextBroj=findViewById(R.id.editText);
        textViewRezultat1=findViewById(R.id.textViewRezultat1);
        textViewRezultat2=findViewById(R.id.textViewRezultat2);
        textViewRezultat3=findViewById(R.id.textViewRezultat3);
        textViewRezultat4=findViewById(R.id.textViewRezultat4);
        textViewRezultat5=findViewById(R.id.textViewRezultat5);

    }

    public void takeNumbersFromEditTextAndPutIntoVariables(){
        br= Double.parseDouble(editTextBroj.getText().toString());
    }

    public void clickButtonKocka(View view) {
        broj = rand.nextInt(6) + 1;
        if (broj == 1) {
            mImageView.setImageResource(R.drawable.jedinica);
            Rez.setText("jedinica");
        } else if (broj == 2) {
            mImageView.setImageResource(R.drawable.dvojka);
            Rez.setText("dvojka");
        } else if (broj == 3) {
            mImageView.setImageResource(R.drawable.trojka);
            Rez.setText("trojka");
        } else if (broj == 4) {
            mImageView.setImageResource(R.drawable.cetvorka);
            Rez.setText("četvorka");
        } else if (broj == 5) {
            mImageView.setImageResource(R.drawable.petica);
            Rez.setText("petica");
        } else if (broj == 6) {
            mImageView.setImageResource(R.drawable.sestica);
            Rez.setText("šestica");
        }
    }

    private static final Map<Character, String> latinToGlagoliticMap = new HashMap<>();

    static {
        latinToGlagoliticMap.put('a', "Ⰰ");
        latinToGlagoliticMap.put('b', "Ⰱ");
        latinToGlagoliticMap.put('v', "Ⰲ");
        latinToGlagoliticMap.put('g', "Ⰳ");
        latinToGlagoliticMap.put('d', "Ⰴ");
        latinToGlagoliticMap.put('e', "Ⰵ");
        latinToGlagoliticMap.put('ž', "Ⰶ");
        latinToGlagoliticMap.put('z', "Ⰷ");
        latinToGlagoliticMap.put('i', "Ⰸ");
        latinToGlagoliticMap.put('j', "Ⰹ");
        latinToGlagoliticMap.put('k', "Ⰺ");
        latinToGlagoliticMap.put('l', "Ⰻ");
        latinToGlagoliticMap.put('m', "Ⰼ");
        latinToGlagoliticMap.put('n', "Ⰽ");
        latinToGlagoliticMap.put('o', "Ⰾ");
        latinToGlagoliticMap.put('p', "Ⰿ");
        latinToGlagoliticMap.put('r', "Ⱀ");
        latinToGlagoliticMap.put('s', "Ⱁ");
        latinToGlagoliticMap.put('t', "Ⱂ");
        latinToGlagoliticMap.put('u', "Ⱃ");
        latinToGlagoliticMap.put('f', "Ⱄ");
        latinToGlagoliticMap.put('h', "Ⱅ");
        latinToGlagoliticMap.put('c', "Ⱆ");
        latinToGlagoliticMap.put('č', "Ⱇ");
        latinToGlagoliticMap.put('š', "Ⱈ");
        latinToGlagoliticMap.put('ŝ', "Ⱉ");
        latinToGlagoliticMap.put('y', "Ⱊ");
        latinToGlagoliticMap.put('ê', "Ⱋ");
        latinToGlagoliticMap.put('â', "Ⱌ");
        latinToGlagoliticMap.put('č', "Ⱍ");
        latinToGlagoliticMap.put('č', "Ⱎ");
        latinToGlagoliticMap.put('ṱ', "Ⱏ");
        latinToGlagoliticMap.put('ě', "Ⱐ");
        latinToGlagoliticMap.put('ü', "Ⱑ");
        latinToGlagoliticMap.put('ô', "Ⱒ");
        latinToGlagoliticMap.put('ï', "Ⱓ");
        latinToGlagoliticMap.put('ӧ', "Ⱔ");
        latinToGlagoliticMap.put('і', "Ⱕ");
        latinToGlagoliticMap.put('ѵ', "Ⱖ");
        latinToGlagoliticMap.put('а', "Ⱗ");
        latinToGlagoliticMap.put('б', "Ⱘ");
        latinToGlagoliticMap.put('в', "Ⱙ");
        latinToGlagoliticMap.put('г', "Ⱚ");
        latinToGlagoliticMap.put('д', "Ⱛ");
        latinToGlagoliticMap.put('є', "Ⱜ");
        latinToGlagoliticMap.put('ж', "Ⱝ");
        latinToGlagoliticMap.put('з', "Ⱞ");
        latinToGlagoliticMap.put('и', "Ⱟ");
        latinToGlagoliticMap.put('ї', "ⰰ");
        latinToGlagoliticMap.put('й', "ⰱ");
        latinToGlagoliticMap.put('к', "ⰲ");
        latinToGlagoliticMap.put('л', "ⰳ");
        latinToGlagoliticMap.put('м', "ⰴ");
        latinToGlagoliticMap.put('н', "ⰵ");
        latinToGlagoliticMap.put('о', "ⰶ");
        latinToGlagoliticMap.put('п', "ⰷ");
        latinToGlagoliticMap.put('р', "ⰸ");
        latinToGlagoliticMap.put('с', "ⰹ");
        latinToGlagoliticMap.put('т', "ⰺ");
        latinToGlagoliticMap.put('у', "ⰻ");
        latinToGlagoliticMap.put('ф', "ⰼ");
        latinToGlagoliticMap.put('х', "ⰽ");
        latinToGlagoliticMap.put('ц', "ⰾ");
        latinToGlagoliticMap.put('ч', "ⰿ");
        latinToGlagoliticMap.put('ш', "ⱀ");
        latinToGlagoliticMap.put('щ', "ⱁ");
        latinToGlagoliticMap.put('ъ', "ⱂ");
        latinToGlagoliticMap.put('ы', "ⱃ");
        latinToGlagoliticMap.put('ь', "ⱄ");
        latinToGlagoliticMap.put('ѡ', "ⱅ");
        latinToGlagoliticMap.put('э', "ⱆ");
        latinToGlagoliticMap.put('ю', "ⱇ");
        latinToGlagoliticMap.put('я', "ⱈ");
    }

    public static String translate(String latinString) {
        StringBuilder glagoliticString = new StringBuilder();

        for (char c : latinString.toCharArray()) {
            String glagoliticChar = latinToGlagoliticMap.getOrDefault(Character.toLowerCase(c), String.valueOf(c));
            glagoliticString.append(glagoliticChar);
        }

        return glagoliticString.toString();
    }

    public void takeNumbersFromEditTextAndPutIntoVariables2(){
        broj1= Double.parseDouble(editTextBroj1.getText().toString());
        broj2= Double.parseDouble(editTextBroj2.getText().toString());
    }
    public void clickButtonIzracunaj(View view){
        takeNumbersFromEditTextAndPutIntoVariables2();
        double BMI= br2/Math.pow(broj1/100,2);
        textViewRezultat.setText(Double.toString(BMI));
    }


    public void Pretvarac(View view){
        takeNumbersFromEditTextAndPutIntoVariables();
        double rez1 = br*117.37;
        double rez2 = br*7.53;
        double rez3 = br*1.96;
        double rez4 = br*383.99;
        double rez5 = br*0.94;
        textViewRezultat1.setText(Double.toString(rez1));
        textViewRezultat2.setText(Double.toString(rez2));
        textViewRezultat3.setText(Double.toString(rez3));
        textViewRezultat4.setText(Double.toString(rez4));
        textViewRezultat5.setText(Double.toString(rez5));
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.mymenu, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
       int id=item.getItemId();
       if (id ==R.id.euro){
           setContentView(R.layout.activity_main);
       }
        if (id ==R.id.Kocka){
            setContentView(R.layout.kocka);
            Rez=findViewById(R.id.Rezultat);
            Slika=findViewById(R.id.Slika);
            mImageView=findViewById(R.id.Slika);
        }
        if(id == R.id.BMI){
            setContentView(R.layout.bmi);
            editTextBroj1=findViewById(R.id.editTextBroj1);
            editTextBroj2=findViewById(R.id.editTextBroj2);
            textViewRezultat=findViewById(R.id.textViewRezultat);
        }
        if(id == R.id.prevoditelj){
            setContentView(R.layout.prevoditelj);
            inputText = findViewById(R.id.inputText);
            translateButton = findViewById(R.id.translateButton);
            outputText = findViewById(R.id.outputText);

            translateButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String latinText = inputText.getText().toString();
                    String translatedText = translate(latinText);
                    outputText.setText(translatedText);
                }
            });
        }

        return super.onOptionsItemSelected(item);
        }


    }
